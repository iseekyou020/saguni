# DevPrompt 使用指南

## 📚 快速索引（按场景查找）

### 🔍 遇到问题？

| 问题 | 解决方案 | 章节 |
|------|----------|------|
| 模板不知道在哪找 | 网站顶部有搜索框 | [快速开始](#快速开始) |
| 不知道选哪个模板 | 按分类浏览 | [快速开始](#快速开始) |
| 变量不知道怎么填 | 模板里有示例 | [使用模板](#使用模板) |
| 找不到需要的模板 | 常见模板列表 | [模板列表](#模板列表) |
| 想自定义模板 | 添加自己的模板 | [自定义模板](#自定义模板) |

---

### 🎯 按使用场景

| 场景 | 推荐模板 |
|------|----------|
| 写代码 | 代码解释器、Bug 修复、代码重构 |
| 写测试 | 单元测试生成、API 测试用例 |
| 写文档 | README 生成、API 文档生成 |
| 查 Bug | Bug 调试助手 |
| 优化性能 | 算法优化顾问、性能测试 |
| 写正则 | 正则表达式生成 |
| 配环境 | Docker 配置、CI/CD |
| 写邮件 | 邮件撰写助手 |
| 做摘要 | 内容摘要生成 |
| 写 SQL | SQL 查询构建 |

---

### 🏷️ 按关键词

| 关键词 | 相关模板 |
|--------|----------|
| JavaScript/Python/Go | 代码解释器、语言转换器 |
| React/Vue | 前端组件生成 |
| MySQL/PostgreSQL | 数据库相关模板 |
| API/REST | API 相关模板 |
| Docker/K8s | DevOps 模板 |
| 测试/Testing | 测试类模板 |
| 性能/优化 | 性能相关模板 |
| 安全/Audit | 安全审计模板 |
| 邮件/沟通 | 效率工具模板 |

---

## 📚 目录

- [快速开始](#快速开始)
- [使用模板](#使用模板)
- [模板列表](#模板列表)
- [自定义模板](#自定义模板)
- [常见问题](#常见问题)
- [贡献指南](#贡献指南)

---

## 🚀 快速开始

### 1. 访问网站

打开 https://devprompt.vercel.app（或本地运行）

### 2. 选择模板

- 按分类浏览（左上角按钮）
- 搜索关键词（顶部搜索框）
- 点击模板查看详情

### 3. 复制使用

- 点击模板卡片的「复制」按钮
- 粘贴到 ChatGPT/Claude
- 替换 `{变量}` 为你的实际内容
- 获取结果！

---

## 📝 使用模板

### 模板结构说明

每个模板包含：

```markdown
## 模板名称
一句话描述

## 使用场景
- 场景1
- 场景2

## 使用方法
1. 复制模板
2. 替换 {变量} 为你的内容
3. 粘贴到 AI 对话框
4. 获取结果

## 示例
```
这是示例内容
```
```

### 变量说明

模板中使用 `{变量名}` 表示需要替换的内容：

| 变量 | 含义 | 示例 |
|------|------|------|
| `{language}` | 编程语言 | Python, JavaScript |
| `{code}` | 你的代码 | console.log("hello") |
| `{requirement}` | 需求描述 | 生成一个用户登录功能 |
| `{description}` | 详细描述 | 这是一个电商网站... |
| `{format}` | 输出格式 | JSON, Markdown |

---

## 📋 模板列表

> 快速查找，按分类排列

### 🔍 代码开发（9 个）

| 模板 | 说明 | 变量 |
|------|------|------|
| 代码解释器 | 解释代码逻辑 | language, code |
| Bug 调试助手 | 定位并修复 Bug | error_message, code |
| 代码重构专家 | 优化代码结构 | language, code |
| 单元测试生成 | 生成测试用例 | language, code |
| 代码审查助手 | 全面代码审查 | language, code |
| 算法优化顾问 | 优化算法复杂度 | language, code |
| 错误处理增强 | 完善错误处理 | language, code |
| 代码注释生成 | 添加清晰注释 | language, code, style |
| 语言转换器 | 转换编程语言 | source_language, target_language, code |

### 📝 文档生成（4 个）

| 模板 | 说明 | 变量 |
|------|------|------|
| API 文档生成 | 生成 API 文档 | language, code |
| README 生成器 | 生成项目文档 | project_structure, description |
| Markdown 文档 | 生成 Markdown | title, type, sections |
| API 错误码设计 | 设计错误码 | modules, http_standard |

### 🗄️ 数据库（4 个）

| 模板 | 说明 | 变量 |
|------|------|------|
| SQL 查询优化 | 生成优化 SQL | requirement, schema |
| 数据库表结构设计 | 设计表结构 | business_requirements |
| 数据库迁移脚本 | 生成迁移脚本 | db_type, direction, schema |
| 数据库种子数据 | 生成 Seed 数据 | project_type, db_type |

### 🛠️ DevOps（5 个）

| 模板 | 说明 | 变量 |
|------|------|------|
| Docker 配置生成 | 生成 Dockerfile | tech_stack, framework |
| Nginx 配置生成 | 生成 Nginx 配置 | service_type, domain |
| GitHub Actions | CI/CD 配置 | trigger, task_type |
| AWS 基础设施 | Terraform 配置 | services_needed, app_type |
| Kubernetes 配置 | K8s 部署配置 | app_type, image, port |

### 🎨 前端开发（4 个）

| 模板 | 说明 | 变量 |
|------|------|------|
| React 组件生成 | 生成 React 组件 | component_function |
| Vue 组件生成 | 生成 Vue 3 组件 | function, ui_description |
| TypeScript 类型 | 生成 TS 类型 | data, usage_scenario |
| CSS 样式生成 | 生成 CSS 样式 | requirement, ui_description |

### ⚡ 效率工具（5 个）

| 模板 | 说明 | 变量 |
|------|------|------|
| 内容摘要生成 | 生成文章摘要 | content, length |
| 大纲生成器 | 生成文章大纲 | topic, type, audience |
| 邮件撰写助手 | 撰写专业邮件 | recipient, purpose, key_points |
| 正则表达式生成 | 生成 Regex | requirement |
| 命令行工具生成 | 生成 CLI 工具 | tool_name, description |

### 📊 数据处理（3 个）

| 模板 | 说明 | 变量 |
|------|------|------|
| 测试数据生成 | 生成 Mock 数据 | data_type, count, fields |
| JSON 数据转换 | 转换 JSON 格式 | input_json, target_format |
| 数据处理脚本 | 生成 ETL 脚本 | data_source, processing_logic |

### 🔗 API 相关（3 个）

| 模板 | 说明 | 变量 |
|------|------|------|
| GraphQL Schema | 生成 GraphQL | requirements, models |
| API Mock 服务 | 生成 Mock 配置 | endpoints, format |
| API 测试用例 | 生成 API 测试 | endpoint, method, parameters |

### 📌 其他工具（4 个）

| 模板 | 说明 | 变量 |
|------|------|------|
| Python 脚本生成 | 生成 Python 脚本 | requirement, input_data |
| Shell 脚本生成 | 生成 Shell 脚本 | function, environment |
| Git 提交信息生成 | 生成 Commit Message | files_changed, change_description |
| 配置文件生成 | 生成项目配置 | config_type, project_type |
| 性能测试脚本 | 生成压测脚本 | test_target, test_scenario |
| 日志配置生成 | 生成日志配置 | tech_stack, log_level |
| 云服务监控 | 监控配置 | services, metrics |
| 安全审计检查 | 安全检查清单 | code_type, tech_stack |

---

### 💡 快速选择指南

**不知道用哪个？试试这些：**

- 想写代码 → `代码解释器`
- 代码有 Bug → `Bug 调试助手`
- 要写测试 → `单元测试生成`
- 要配环境 → `Docker 配置生成`
- 要写文档 → `README 生成器`
- 要查正则 → `正则表达式生成`
- 要发邮件 → `邮件撰写助手`
- 要做摘要 → `内容摘要生成`

---

## 🎨 自定义模板

### 方法 1：在线调整

1. 复制模板
2. 在文本编辑器中修改 `{变量}`
3. 直接使用

### 方法 2：创建专属模板

如果你有常用的 Prompt，可以：

1. Fork 本项目
2. 在 `src/data/templates.ts` 中添加新模板
3. 提交 PR

### 模板格式

```typescript
{
  id: "unique-id",          // 唯一标识符
  title: "模板标题",         // 简洁明了
  description: "简短描述",   // 一句话说明用途
  category: "所属分类",      // 选择现有分类或新增
  prompt: `完整的 Prompt 模板
  使用 {placeholder} 表示变量`,
  tags: ["标签1", "标签2"],  // 便于搜索
  isPremium: false          // 是否付费模板
}
```

---

## ❓ 常见问题

### Q: 模板支持哪些 AI？

A: 支持所有大语言模型
- ChatGPT
- Claude
- Gemini
- 通义千问
- 文心一言
- ...

### Q: 模板收费吗？

A: 当前全部免费。后续会推出高级模板。

### Q: 模板可以商用吗？

A: MIT 许可证，可以自由使用。

### Q: 找不到需要的模板？

A: 可以在 GitHub 提 Issue 或自行添加后提交 PR。

---

## 🤝 贡献指南

我们欢迎任何人贡献模板！

### 贡献步骤

1. **Fork 项目**
   ```
   https://github.com/yourusername/devprompt
   ```

2. **创建分支**
   ```bash
   git checkout -b add-my-template
   ```

3. **添加模板**
   - 编辑 `src/data/templates.ts`
   - 按照模板格式添加新模板

4. **测试运行**
   ```bash
   npm run dev
   ```

5. **提交 PR**
   - 描述你的模板用途
   - 提交 Pull Request

### 模板规范

✅ **好的模板应该：**
- 有清晰的使用场景
- 变量命名直观易懂
- Prompt 结构完整
- 有使用示例

❌ **避免：**
- 过于复杂的 Prompt
- 变量过多（建议不超过 5 个）
- 过于通用的描述

---

## 📞 联系我们

- GitHub: https://github.com/yourusername/devprompt
- Issue: https://github.com/yourusername/devprompt/issues

---

**让 AI 帮你写更好的代码！** 🚀
